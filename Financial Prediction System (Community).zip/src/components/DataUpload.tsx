import { useState } from 'react';
import { Upload, Database, Globe } from 'lucide-react';
import { generateSampleData } from '../utils/sampleData';

interface DataUploadProps {
  onDataLoaded: (data: any) => void;
}

export function DataUpload({ onDataLoaded }: DataUploadProps) {
  const [loading, setLoading] = useState(false);
  const [dataSource, setDataSource] = useState<string>('');

  const handleLoadSampleData = () => {
    setLoading(true);
    setTimeout(() => {
      const sampleData = generateSampleData();
      onDataLoaded(sampleData);
      setLoading(false);
      setDataSource('Sample Data Generated');
    }, 1000);
  };

  const dataSources = [
    {
      name: 'World Bank',
      url: 'https://www.worldbank.org/ext/en/home',
      weight: 'Double',
      status: 'Mock Available'
    },
    {
      name: 'IMF Egypt',
      url: 'https://www.imf.org/en/countries/egy',
      weight: 'Double',
      status: 'Mock Available'
    },
    {
      name: 'Fitch Solutions',
      url: 'https://www.fitchsolutions.com/',
      weight: 'Double',
      status: 'Mock Available'
    },
    {
      name: 'S&P Global',
      url: 'https://www.spglobal.com/',
      weight: 'Single',
      status: 'Mock Available'
    },
    {
      name: 'HC',
      url: 'https://www.hc-si.com/',
      weight: 'Single',
      status: 'Mock Available'
    },
    {
      name: 'Benton',
      url: 'https://www.bentonpud.org/',
      weight: 'Single',
      status: 'Mock Available'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center gap-3 mb-6">
          <Database className="w-8 h-8 text-blue-600" />
          <div>
            <h2 className="text-2xl">Data Sources</h2>
            <p className="text-slate-600">Load historical financial data for analysis</p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-4 mb-6">
          <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center hover:border-blue-500 transition-colors cursor-pointer">
            <Upload className="w-12 h-12 mx-auto mb-3 text-slate-400" />
            <h3 className="mb-2">Upload Excel Files</h3>
            <p className="text-sm text-slate-500 mb-3">
              Upload your historical data files:
            </p>
            <ul className="text-sm text-slate-600 text-left space-y-1">
              <li>• Exchange Rates Historical.xlsx</li>
              <li>• Discount Rates.xlsx</li>
              <li>• Egyptian Pound Index.xlsx</li>
              <li>• Inflations Historical.xlsx</li>
            </ul>
            <input 
              type="file" 
              multiple 
              accept=".xlsx,.xls,.csv"
              className="hidden"
              id="file-upload"
            />
            <label 
              htmlFor="file-upload"
              className="inline-block mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 cursor-pointer"
            >
              Select Files
            </label>
          </div>

          <div className="border-2 border-blue-500 rounded-lg p-6 bg-blue-50">
            <Database className="w-12 h-12 mx-auto mb-3 text-blue-600" />
            <h3 className="mb-2">Use Sample Data</h3>
            <p className="text-sm text-slate-600 mb-4">
              Load pre-configured sample data for demonstration
            </p>
            <button
              onClick={handleLoadSampleData}
              disabled={loading}
              className="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Loading...' : 'Load Sample Data'}
            </button>
            {dataSource && (
              <p className="mt-3 text-sm text-green-600">✓ {dataSource}</p>
            )}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center gap-3 mb-4">
          <Globe className="w-6 h-6 text-green-600" />
          <h3 className="text-xl">External Data Sources</h3>
        </div>
        <p className="text-sm text-slate-600 mb-4">
          The system integrates with the following weighted data sources:
        </p>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
          {dataSources.map((source) => (
            <div key={source.name} className="border border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow">
              <div className="flex justify-between items-start mb-2">
                <h4 className="font-medium">{source.name}</h4>
                <span className={`text-xs px-2 py-1 rounded ${
                  source.weight === 'Double' 
                    ? 'bg-purple-100 text-purple-700' 
                    : 'bg-blue-100 text-blue-700'
                }`}>
                  {source.weight}
                </span>
              </div>
              <p className="text-xs text-slate-500 mb-2 truncate">{source.url}</p>
              <span className="text-xs text-green-600">{source.status}</span>
            </div>
          ))}
        </div>
        <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-md">
          <p className="text-sm text-amber-800">
            <strong>Note:</strong> External API calls use mock data for demonstration. 
            Replace API_KEY placeholders with actual credentials for live data integration.
          </p>
        </div>
      </div>
    </div>
  );
}
