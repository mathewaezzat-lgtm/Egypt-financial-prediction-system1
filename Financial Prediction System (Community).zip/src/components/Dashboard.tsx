import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, Activity } from 'lucide-react';
import { formatDate } from '../utils/sampleData';

interface DashboardProps {
  data: any;
}

export function Dashboard({ data }: DashboardProps) {
  if (!data) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-12 text-center">
        <Activity className="w-16 h-16 mx-auto mb-4 text-slate-300" />
        <h3 className="text-xl mb-2 text-slate-600">No Data Loaded</h3>
        <p className="text-slate-500">Please load data from the Data Upload tab to view historical charts.</p>
      </div>
    );
  }

  const formatChartData = (dataPoints: any[]) => {
    return dataPoints.map(point => ({
      date: formatDate(new Date(point.date)),
      value: point.value,
      timestamp: new Date(point.date).getTime()
    })).sort((a, b) => a.timestamp - b.timestamp);
  };

  const exchangeData = formatChartData(data.exchangeRates);
  const discountData = formatChartData(data.discountRates);
  const inflationData = formatChartData(data.inflationRates);
  const indexData = formatChartData(data.egyptianPoundIndex);

  const calculateStats = (dataPoints: any[]) => {
    const values = dataPoints.map(d => d.value);
    const latest = values[values.length - 1];
    const previous = values[values.length - 2];
    const change = latest - previous;
    const changePercent = ((change / previous) * 100).toFixed(2);
    const avg = (values.reduce((a, b) => a + b, 0) / values.length).toFixed(2);
    const max = Math.max(...values).toFixed(2);
    const min = Math.min(...values).toFixed(2);
    
    return { latest, change, changePercent, avg, max, min };
  };

  const exchangeStats = calculateStats(exchangeData);
  const discountStats = calculateStats(discountData);
  const inflationStats = calculateStats(inflationData);
  const indexStats = calculateStats(indexData);

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg shadow-lg p-6 text-white">
          <h3 className="text-sm opacity-90 mb-2">Exchange Rate (EGP/USD)</h3>
          <div className="flex items-end justify-between">
            <div>
              <p className="text-3xl mb-1">{exchangeStats.latest}</p>
              <div className="flex items-center gap-1 text-sm">
                {exchangeStats.change > 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                <span>{exchangeStats.changePercent}%</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg shadow-lg p-6 text-white">
          <h3 className="text-sm opacity-90 mb-2">Discount Rate (%)</h3>
          <div className="flex items-end justify-between">
            <div>
              <p className="text-3xl mb-1">{discountStats.latest}</p>
              <div className="flex items-center gap-1 text-sm">
                {discountStats.change > 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                <span>{discountStats.changePercent}%</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg shadow-lg p-6 text-white">
          <h3 className="text-sm opacity-90 mb-2">Inflation Rate (%)</h3>
          <div className="flex items-end justify-between">
            <div>
              <p className="text-3xl mb-1">{inflationStats.latest}</p>
              <div className="flex items-center gap-1 text-sm">
                {inflationStats.change > 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                <span>{inflationStats.changePercent}%</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-lg shadow-lg p-6 text-white">
          <h3 className="text-sm opacity-90 mb-2">EGP Index</h3>
          <div className="flex items-end justify-between">
            <div>
              <p className="text-3xl mb-1">{indexStats.latest}</p>
              <div className="flex items-center gap-1 text-sm">
                {indexStats.change > 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                <span>{indexStats.changePercent}%</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Exchange Rate Chart */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h3 className="text-xl mb-4">Historical Exchange Rate (EGP/USD)</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={exchangeData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tick={{ fontSize: 12 }}
                interval="preserveStartEnd"
              />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="value" stroke="#3b82f6" strokeWidth={2} name="EGP/USD" />
            </LineChart>
          </ResponsiveContainer>
          <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
            <div>
              <p className="text-slate-500">Average</p>
              <p className="font-semibold">{exchangeStats.avg}</p>
            </div>
            <div>
              <p className="text-slate-500">Maximum</p>
              <p className="font-semibold">{exchangeStats.max}</p>
            </div>
            <div>
              <p className="text-slate-500">Minimum</p>
              <p className="font-semibold">{exchangeStats.min}</p>
            </div>
          </div>
        </div>

        {/* Discount Rate Chart */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h3 className="text-xl mb-4">Historical Discount Rate</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={discountData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tick={{ fontSize: 12 }}
                interval="preserveStartEnd"
              />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="value" stroke="#a855f7" strokeWidth={2} name="Discount Rate %" />
            </LineChart>
          </ResponsiveContainer>
          <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
            <div>
              <p className="text-slate-500">Average</p>
              <p className="font-semibold">{discountStats.avg}%</p>
            </div>
            <div>
              <p className="text-slate-500">Maximum</p>
              <p className="font-semibold">{discountStats.max}%</p>
            </div>
            <div>
              <p className="text-slate-500">Minimum</p>
              <p className="font-semibold">{discountStats.min}%</p>
            </div>
          </div>
        </div>

        {/* Inflation Rate Chart */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h3 className="text-xl mb-4">Historical Inflation Rate</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={inflationData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tick={{ fontSize: 12 }}
                interval="preserveStartEnd"
              />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="value" stroke="#f97316" strokeWidth={2} name="Inflation Rate %" />
            </LineChart>
          </ResponsiveContainer>
          <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
            <div>
              <p className="text-slate-500">Average</p>
              <p className="font-semibold">{inflationStats.avg}%</p>
            </div>
            <div>
              <p className="text-slate-500">Maximum</p>
              <p className="font-semibold">{inflationStats.max}%</p>
            </div>
            <div>
              <p className="text-slate-500">Minimum</p>
              <p className="font-semibold">{inflationStats.min}%</p>
            </div>
          </div>
        </div>

        {/* Egyptian Pound Index Chart */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h3 className="text-xl mb-4">Egyptian Pound Index</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={indexData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tick={{ fontSize: 12 }}
                interval="preserveStartEnd"
              />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="value" stroke="#22c55e" strokeWidth={2} name="EGP Index" />
            </LineChart>
          </ResponsiveContainer>
          <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
            <div>
              <p className="text-slate-500">Average</p>
              <p className="font-semibold">{indexStats.avg}</p>
            </div>
            <div>
              <p className="text-slate-500">Maximum</p>
              <p className="font-semibold">{indexStats.max}</p>
            </div>
            <div>
              <p className="text-slate-500">Minimum</p>
              <p className="font-semibold">{indexStats.min}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
