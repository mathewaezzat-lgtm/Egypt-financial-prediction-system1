import { useState, useEffect } from 'react';
import { ArrowDownUp, TrendingUp, TrendingDown, Clock, DollarSign } from 'lucide-react';

interface CurrencyConverterProps {
  historicalData: any;
}

export function CurrencyConverter({ historicalData }: CurrencyConverterProps) {
  const [fromCurrency, setFromCurrency] = useState<'USD' | 'EGP'>('USD');
  const [toCurrency, setToCurrency] = useState<'USD' | 'EGP'>('EGP');
  const [fromAmount, setFromAmount] = useState<string>('100');
  const [toAmount, setToAmount] = useState<string>('0');
  const [currentRate, setCurrentRate] = useState<number>(0);
  const [previousRate, setPreviousRate] = useState<number>(0);
  const [rateChange, setRateChange] = useState<number>(0);
  const [conversionHistory, setConversionHistory] = useState<any[]>([]);

  useEffect(() => {
    if (historicalData && historicalData.exchangeRates) {
      const rates = historicalData.exchangeRates;
      const latest = rates[rates.length - 1].value;
      const previous = rates[rates.length - 2]?.value || latest;
      
      setCurrentRate(latest);
      setPreviousRate(previous);
      setRateChange(((latest - previous) / previous) * 100);
    }
  }, [historicalData]);

  useEffect(() => {
    calculateConversion();
  }, [fromAmount, fromCurrency, toCurrency, currentRate]);

  const calculateConversion = () => {
    if (!currentRate || !fromAmount) {
      setToAmount('0');
      return;
    }

    const amount = parseFloat(fromAmount) || 0;
    let result = 0;

    if (fromCurrency === 'USD' && toCurrency === 'EGP') {
      result = amount * currentRate;
    } else if (fromCurrency === 'EGP' && toCurrency === 'USD') {
      result = amount / currentRate;
    } else {
      result = amount; // Same currency
    }

    setToAmount(result.toFixed(2));
  };

  const handleSwap = () => {
    // Swap currencies
    const tempCurrency = fromCurrency;
    setFromCurrency(toCurrency);
    setToCurrency(tempCurrency);

    // Swap amounts
    const tempAmount = fromAmount;
    setFromAmount(toAmount);
    setToAmount(tempAmount);
  };

  const addToHistory = () => {
    if (!fromAmount || parseFloat(fromAmount) === 0) return;

    const newEntry = {
      id: Date.now(),
      timestamp: new Date(),
      fromCurrency,
      toCurrency,
      fromAmount: parseFloat(fromAmount),
      toAmount: parseFloat(toAmount),
      rate: currentRate,
    };

    setConversionHistory([newEntry, ...conversionHistory.slice(0, 9)]);
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(date);
  };

  if (!historicalData) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-12 text-center">
        <DollarSign className="w-16 h-16 mx-auto mb-4 text-slate-300" />
        <h3 className="text-xl mb-2 text-slate-600">Converter Not Available</h3>
        <p className="text-slate-500">Please load historical data first to use the currency converter.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Exchange Rate Card */}
      <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg shadow-lg p-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-sm opacity-90 mb-1">Current Exchange Rate</p>
            <h2 className="text-4xl">
              {currentRate.toFixed(4)} <span className="text-2xl">EGP/USD</span>
            </h2>
          </div>
          <div className="text-right">
            <p className="text-sm opacity-90 mb-1">24h Change</p>
            <div className={`text-2xl flex items-center gap-2 justify-end ${
              rateChange >= 0 ? 'text-green-200' : 'text-red-200'
            }`}>
              {rateChange >= 0 ? <TrendingUp className="w-6 h-6" /> : <TrendingDown className="w-6 h-6" />}
              <span>{rateChange >= 0 ? '+' : ''}{rateChange.toFixed(2)}%</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-4 text-sm opacity-75">
          <span>Previous: {previousRate.toFixed(4)}</span>
          <span>•</span>
          <span>Updated: {historicalData.exchangeRates && formatDate(new Date(historicalData.exchangeRates[historicalData.exchangeRates.length - 1].date))}</span>
        </div>
      </div>

      {/* Converter Card */}
      <div className="bg-white rounded-lg shadow-lg p-8">
        <h2 className="text-2xl mb-6">Currency Converter</h2>

        <div className="space-y-4">
          {/* From Currency */}
          <div>
            <label className="block text-sm text-slate-600 mb-2">From</label>
            <div className="flex gap-3">
              <div className="flex-1">
                <input
                  type="number"
                  value={fromAmount}
                  onChange={(e) => setFromAmount(e.target.value)}
                  onBlur={addToHistory}
                  className="w-full px-4 py-3 border-2 border-slate-300 rounded-lg text-xl focus:border-blue-500 focus:outline-none"
                  placeholder="0.00"
                  step="0.01"
                />
              </div>
              <select
                value={fromCurrency}
                onChange={(e) => setFromCurrency(e.target.value as 'USD' | 'EGP')}
                className="px-4 py-3 border-2 border-slate-300 rounded-lg text-xl focus:border-blue-500 focus:outline-none bg-white cursor-pointer"
              >
                <option value="USD">USD</option>
                <option value="EGP">EGP</option>
              </select>
            </div>
          </div>

          {/* Swap Button */}
          <div className="flex justify-center">
            <button
              onClick={handleSwap}
              className="p-3 bg-blue-100 hover:bg-blue-200 rounded-full transition-colors group"
              aria-label="Swap currencies"
            >
              <ArrowDownUp className="w-6 h-6 text-blue-600 group-hover:rotate-180 transition-transform duration-300" />
            </button>
          </div>

          {/* To Currency */}
          <div>
            <label className="block text-sm text-slate-600 mb-2">To</label>
            <div className="flex gap-3">
              <div className="flex-1">
                <input
                  type="text"
                  value={toAmount}
                  readOnly
                  className="w-full px-4 py-3 border-2 border-slate-300 rounded-lg text-xl bg-slate-50"
                  placeholder="0.00"
                />
              </div>
              <select
                value={toCurrency}
                onChange={(e) => setToCurrency(e.target.value as 'USD' | 'EGP')}
                className="px-4 py-3 border-2 border-slate-300 rounded-lg text-xl focus:border-blue-500 focus:outline-none bg-white cursor-pointer"
              >
                <option value="USD">USD</option>
                <option value="EGP">EGP</option>
              </select>
            </div>
          </div>

          {/* Conversion Info */}
          {fromCurrency !== toCurrency && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-slate-700">
                <strong>1 {fromCurrency}</strong> = {' '}
                <strong>
                  {fromCurrency === 'USD' 
                    ? currentRate.toFixed(4) 
                    : (1 / currentRate).toFixed(6)
                  } {toCurrency}
                </strong>
              </p>
              <p className="text-xs text-slate-600 mt-1">
                Inverse rate: 1 {toCurrency} = {' '}
                {fromCurrency === 'USD' 
                  ? (1 / currentRate).toFixed(6)
                  : currentRate.toFixed(4)
                } {fromCurrency}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Quick Conversion Reference */}
      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h3 className="text-xl mb-4">USD to EGP</h3>
          <div className="space-y-3">
            {[1, 10, 50, 100, 500, 1000].map(amount => (
              <div key={amount} className="flex justify-between items-center py-2 border-b border-slate-200">
                <span className="text-slate-600">${amount} USD</span>
                <span className="font-semibold">{(amount * currentRate).toFixed(2)} EGP</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6">
          <h3 className="text-xl mb-4">EGP to USD</h3>
          <div className="space-y-3">
            {[100, 500, 1000, 5000, 10000, 50000].map(amount => (
              <div key={amount} className="flex justify-between items-center py-2 border-b border-slate-200">
                <span className="text-slate-600">{amount.toLocaleString()} EGP</span>
                <span className="font-semibold">${(amount / currentRate).toFixed(2)} USD</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Conversion History */}
      {conversionHistory.length > 0 && (
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center gap-2 mb-4">
            <Clock className="w-5 h-5 text-slate-600" />
            <h3 className="text-xl">Recent Conversions</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-100">
                <tr>
                  <th className="p-3 text-left">Time</th>
                  <th className="p-3 text-right">From</th>
                  <th className="p-3 text-center">→</th>
                  <th className="p-3 text-right">To</th>
                  <th className="p-3 text-right">Rate</th>
                </tr>
              </thead>
              <tbody>
                {conversionHistory.map(entry => (
                  <tr key={entry.id} className="border-b border-slate-200 hover:bg-slate-50">
                    <td className="p-3 text-slate-600">{formatDate(entry.timestamp)}</td>
                    <td className="p-3 text-right">
                      {entry.fromAmount.toLocaleString()} {entry.fromCurrency}
                    </td>
                    <td className="p-3 text-center text-slate-400">→</td>
                    <td className="p-3 text-right font-semibold">
                      {entry.toAmount.toLocaleString()} {entry.toCurrency}
                    </td>
                    <td className="p-3 text-right text-slate-600">
                      {entry.rate.toFixed(4)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Additional Info */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-xl mb-4">Exchange Rate Information</h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h4 className="text-sm text-slate-600 mb-2">About EGP/USD Rate</h4>
            <p className="text-sm text-slate-700 leading-relaxed">
              The Egyptian Pound (EGP) to US Dollar (USD) exchange rate represents how many Egyptian Pounds 
              are needed to purchase one US Dollar. This rate is influenced by various economic factors including 
              inflation, interest rates, trade balance, and monetary policy decisions by the Central Bank of Egypt.
            </p>
          </div>
          <div>
            <h4 className="text-sm text-slate-600 mb-2">Rate Updates</h4>
            <p className="text-sm text-slate-700 leading-relaxed">
              Exchange rates are updated based on the historical data loaded into the system. For real-time 
              trading, always consult with official forex providers or banks. The rates shown here are for 
              analytical and educational purposes.
            </p>
          </div>
        </div>
        <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-md">
          <p className="text-sm text-amber-800">
            <strong>Note:</strong> Actual exchange rates may vary between banks and exchange services. 
            Always verify current rates before making financial transactions. Transaction fees and commissions are not included in these calculations.
          </p>
        </div>
      </div>
    </div>
  );
}
