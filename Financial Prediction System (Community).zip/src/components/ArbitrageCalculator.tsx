import { useState, useEffect } from 'react';
import { DollarSign, AlertTriangle, CheckCircle, TrendingUp, Calculator } from 'lucide-react';

interface ArbitrageCalculatorProps {
  historicalData: any;
  predictions: any;
}

interface ArbitrageOpportunity {
  type: string;
  description: string;
  expectedProfit: number;
  profitPercentage: number;
  risk: 'Low' | 'Medium' | 'High';
  strategy: string;
  timeframe: string;
}

export function ArbitrageCalculator({ historicalData, predictions }: ArbitrageCalculatorProps) {
  const [opportunities, setOpportunities] = useState<ArbitrageOpportunity[]>([]);
  const [investmentAmount, setInvestmentAmount] = useState(10000);

  useEffect(() => {
    if (historicalData && predictions) {
      calculateArbitrage();
    }
  }, [historicalData, predictions, investmentAmount]);

  const calculateArbitrage = () => {
    if (!historicalData || !predictions) return;

    const opportunities: ArbitrageOpportunity[] = [];

    // Get current and predicted values
    const currentExchangeRate = historicalData.exchangeRates[historicalData.exchangeRates.length - 1].value;
    const predictedExchangeRate = predictions.exchangeRates.predictions[5].value; // 6 months ahead
    const currentInflation = historicalData.inflationRates[historicalData.inflationRates.length - 1].value;
    const predictedInflation = predictions.inflationRates.predictions[5].value;
    const currentDiscount = historicalData.discountRates[historicalData.discountRates.length - 1].value;
    const predictedDiscount = predictions.discountRates.predictions[5].value;

    // 1. Currency Arbitrage
    const exchangeRateDiff = ((predictedExchangeRate - currentExchangeRate) / currentExchangeRate) * 100;
    if (Math.abs(exchangeRateDiff) > 2) {
      const profit = (investmentAmount * Math.abs(exchangeRateDiff)) / 100;
      opportunities.push({
        type: 'Currency Arbitrage',
        description: exchangeRateDiff > 0 
          ? `EGP expected to depreciate by ${exchangeRateDiff.toFixed(2)}%. Convert USD to EGP now and reconvert later.`
          : `EGP expected to appreciate by ${Math.abs(exchangeRateDiff).toFixed(2)}%. Hold EGP position.`,
        expectedProfit: parseFloat(profit.toFixed(2)),
        profitPercentage: parseFloat(Math.abs(exchangeRateDiff).toFixed(2)),
        risk: Math.abs(exchangeRateDiff) > 5 ? 'High' : 'Medium',
        strategy: 'Foreign Exchange Position',
        timeframe: '6 months'
      });
    }

    // 2. Interest Rate Arbitrage
    const discountRateDiff = predictedDiscount - currentDiscount;
    if (Math.abs(discountRateDiff) > 0.5) {
      const profit = (investmentAmount * currentDiscount * 0.5) / 100; // 6 months interest
      opportunities.push({
        type: 'Interest Rate Arbitrage',
        description: discountRateDiff > 0
          ? `Discount rate expected to rise to ${predictedDiscount.toFixed(2)}%. Lock in current rates before increase.`
          : `Discount rate expected to fall to ${predictedDiscount.toFixed(2)}%. Consider variable rate instruments.`,
        expectedProfit: parseFloat(profit.toFixed(2)),
        profitPercentage: parseFloat((currentDiscount / 2).toFixed(2)),
        risk: 'Low',
        strategy: 'Fixed Income Securities',
        timeframe: '6 months'
      });
    }

    // 3. Inflation-Protected Arbitrage
    const inflationDiff = predictedInflation - currentInflation;
    if (inflationDiff > 1) {
      const realReturn = currentDiscount - predictedInflation;
      const profit = (investmentAmount * Math.max(realReturn, 0)) / 100;
      opportunities.push({
        type: 'Inflation Hedge',
        description: `Inflation expected to rise to ${predictedInflation.toFixed(2)}%. Real return may be negative. Consider inflation-protected securities.`,
        expectedProfit: parseFloat(profit.toFixed(2)),
        profitPercentage: parseFloat(realReturn.toFixed(2)),
        risk: 'Medium',
        strategy: 'Inflation-Linked Bonds',
        timeframe: '12 months'
      });
    }

    // 4. Carry Trade Opportunity
    const carryTradePotential = currentDiscount - (currentInflation + exchangeRateDiff / 2);
    if (carryTradePotential > 2) {
      const profit = (investmentAmount * carryTradePotential) / 100;
      opportunities.push({
        type: 'Carry Trade',
        description: `Positive carry of ${carryTradePotential.toFixed(2)}% after adjusting for inflation and currency risk.`,
        expectedProfit: parseFloat(profit.toFixed(2)),
        profitPercentage: parseFloat(carryTradePotential.toFixed(2)),
        risk: 'High',
        strategy: 'Leveraged Position',
        timeframe: '6 months'
      });
    }

    // 5. Triangular Arbitrage (Synthetic)
    const syntheticRate = currentExchangeRate * (1 + currentInflation / 100);
    const actualPredicted = predictedExchangeRate;
    const arbitrageGap = ((actualPredicted - syntheticRate) / syntheticRate) * 100;
    
    if (Math.abs(arbitrageGap) > 1) {
      const profit = (investmentAmount * Math.abs(arbitrageGap)) / 100;
      opportunities.push({
        type: 'Synthetic Arbitrage',
        description: `Market inefficiency detected. Synthetic rate ${syntheticRate.toFixed(2)} vs predicted ${actualPredicted.toFixed(2)}.`,
        expectedProfit: parseFloat(profit.toFixed(2)),
        profitPercentage: parseFloat(Math.abs(arbitrageGap).toFixed(2)),
        risk: 'Medium',
        strategy: 'Multi-leg Strategy',
        timeframe: '3-6 months'
      });
    }

    setOpportunities(opportunities);
  };

  if (!historicalData || !predictions) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-12 text-center">
        <Calculator className="w-16 h-16 mx-auto mb-4 text-slate-300" />
        <h3 className="text-xl mb-2 text-slate-600">Arbitrage Calculator Not Available</h3>
        <p className="text-slate-500">Please load historical data and generate predictions first.</p>
      </div>
    );
  }

  const totalPotentialProfit = opportunities.reduce((sum, opp) => sum + opp.expectedProfit, 0);
  const highRiskCount = opportunities.filter(opp => opp.risk === 'High').length;
  const mediumRiskCount = opportunities.filter(opp => opp.risk === 'Medium').length;
  const lowRiskCount = opportunities.filter(opp => opp.risk === 'Low').length;

  return (
    <div className="space-y-6">
      {/* Calculator Header */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Calculator className="w-8 h-8 text-green-600" />
            <div>
              <h2 className="text-2xl">Arbitrage Opportunity Calculator</h2>
              <p className="text-slate-600">Identify profit opportunities based on market inefficiencies</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right">
              <label className="text-sm text-slate-600 block mb-1">Investment Amount (USD)</label>
              <input
                type="number"
                value={investmentAmount}
                onChange={(e) => setInvestmentAmount(parseFloat(e.target.value) || 0)}
                className="px-4 py-2 border border-slate-300 rounded-md w-40"
                min="100"
                step="1000"
              />
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-4 gap-4">
          <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-lg p-4 text-white">
            <p className="text-sm opacity-90 mb-1">Total Opportunities</p>
            <p className="text-3xl">{opportunities.length}</p>
          </div>
          
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg p-4 text-white">
            <p className="text-sm opacity-90 mb-1">Potential Profit</p>
            <p className="text-3xl">${totalPotentialProfit.toFixed(0)}</p>
          </div>
          
          <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg p-4 text-white">
            <p className="text-sm opacity-90 mb-1">Average Return</p>
            <p className="text-3xl">
              {opportunities.length > 0 
                ? ((totalPotentialProfit / investmentAmount) * 100).toFixed(1)
                : '0'}%
            </p>
          </div>
          
          <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg p-4 text-white">
            <p className="text-sm opacity-90 mb-1">Risk Distribution</p>
            <p className="text-sm">
              Low: {lowRiskCount} | Med: {mediumRiskCount} | High: {highRiskCount}
            </p>
          </div>
        </div>
      </div>

      {/* Opportunities List */}
      {opportunities.length === 0 ? (
        <div className="bg-white rounded-lg shadow-lg p-12 text-center">
          <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-500" />
          <h3 className="text-xl mb-2">No Significant Arbitrage Opportunities</h3>
          <p className="text-slate-600">Current market conditions show efficient pricing. Continue monitoring for changes.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {opportunities.map((opp, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg p-6 border-l-4" style={{
              borderLeftColor: opp.risk === 'High' ? '#ef4444' : opp.risk === 'Medium' ? '#f59e0b' : '#22c55e'
            }}>
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-start gap-3">
                  <div className={`p-3 rounded-lg ${
                    opp.risk === 'High' ? 'bg-red-100' : 
                    opp.risk === 'Medium' ? 'bg-orange-100' : 
                    'bg-green-100'
                  }`}>
                    {opp.risk === 'High' ? (
                      <AlertTriangle className="w-6 h-6 text-red-600" />
                    ) : opp.risk === 'Medium' ? (
                      <TrendingUp className="w-6 h-6 text-orange-600" />
                    ) : (
                      <CheckCircle className="w-6 h-6 text-green-600" />
                    )}
                  </div>
                  
                  <div>
                    <h3 className="text-xl mb-1">{opp.type}</h3>
                    <p className="text-slate-600 mb-2">{opp.description}</p>
                    <div className="flex items-center gap-4 text-sm">
                      <span className="text-slate-500">Strategy: <strong>{opp.strategy}</strong></span>
                      <span className="text-slate-500">Timeframe: <strong>{opp.timeframe}</strong></span>
                      <span className={`px-2 py-1 rounded ${
                        opp.risk === 'High' ? 'bg-red-100 text-red-700' :
                        opp.risk === 'Medium' ? 'bg-orange-100 text-orange-700' :
                        'bg-green-100 text-green-700'
                      }`}>
                        {opp.risk} Risk
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="text-right">
                  <p className="text-sm text-slate-500 mb-1">Expected Profit</p>
                  <p className="text-3xl text-green-600 mb-1">${opp.expectedProfit.toLocaleString()}</p>
                  <p className="text-lg text-slate-600">+{opp.profitPercentage}%</p>
                </div>
              </div>

              <div className="bg-slate-50 rounded-lg p-4">
                <h4 className="text-sm mb-2 text-slate-700">Execution Details</h4>
                <div className="grid md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <p className="text-slate-500">Initial Investment</p>
                    <p className="font-semibold">${investmentAmount.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-slate-500">Expected Return</p>
                    <p className="font-semibold">${(investmentAmount + opp.expectedProfit).toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-slate-500">ROI</p>
                    <p className="font-semibold">{opp.profitPercentage}%</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Arbitrage Methodology */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-xl mb-4">Arbitrage Calculation Methodology</h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h4 className="mb-3 flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-blue-600" />
              Detection Methods
            </h4>
            <ul className="space-y-2 text-sm text-slate-700">
              <li className="flex gap-2">
                <span className="text-blue-600">•</span>
                <span><strong>Currency Arbitrage:</strong> Exchange rate predictions vs current rates</span>
              </li>
              <li className="flex gap-2">
                <span className="text-blue-600">•</span>
                <span><strong>Interest Rate Arbitrage:</strong> Discount rate differential opportunities</span>
              </li>
              <li className="flex gap-2">
                <span className="text-blue-600">•</span>
                <span><strong>Inflation Hedge:</strong> Real return calculations and protection strategies</span>
              </li>
              <li className="flex gap-2">
                <span className="text-blue-600">•</span>
                <span><strong>Carry Trade:</strong> Net interest differential after currency risk</span>
              </li>
              <li className="flex gap-2">
                <span className="text-blue-600">•</span>
                <span><strong>Synthetic Arbitrage:</strong> Market inefficiencies in related instruments</span>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="mb-3 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-600" />
              Risk Considerations
            </h4>
            <ul className="space-y-2 text-sm text-slate-700">
              <li className="flex gap-2">
                <span className="text-orange-600">•</span>
                <span><strong>Market Risk:</strong> Predictions may not materialize as expected</span>
              </li>
              <li className="flex gap-2">
                <span className="text-orange-600">•</span>
                <span><strong>Liquidity Risk:</strong> Ability to execute trades at desired prices</span>
              </li>
              <li className="flex gap-2">
                <span className="text-orange-600">•</span>
                <span><strong>Currency Risk:</strong> Exchange rate volatility and transaction costs</span>
              </li>
              <li className="flex gap-2">
                <span className="text-orange-600">•</span>
                <span><strong>Political Risk:</strong> Regulatory changes affecting Egyptian markets</span>
              </li>
              <li className="flex gap-2">
                <span className="text-orange-600">•</span>
                <span><strong>Model Risk:</strong> Limitations of prediction algorithms</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-md">
          <p className="text-sm text-amber-800">
            <strong>Disclaimer:</strong> These are theoretical calculations based on predictive models. 
            Actual arbitrage opportunities require real-time market data, transaction costs consideration, 
            and professional risk management. Consult with financial advisors before making investment decisions.
          </p>
        </div>
      </div>
    </div>
  );
}
