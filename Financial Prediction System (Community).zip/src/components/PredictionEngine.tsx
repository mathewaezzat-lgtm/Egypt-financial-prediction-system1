import { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Area, AreaChart } from 'recharts';
import { Brain, TrendingUp, Calendar, Activity } from 'lucide-react';
import { formatDate, calculateExpected, predictNextValue } from '../utils/sampleData';

interface PredictionEngineProps {
  historicalData: any;
  onPredictionsGenerated: (predictions: any) => void;
}

export function PredictionEngine({ historicalData, onPredictionsGenerated }: PredictionEngineProps) {
  const [predictions, setPredictions] = useState<any>(null);
  const [predictionMonths, setPredictionMonths] = useState(12);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (historicalData && !predictions) {
      generatePredictions();
    }
  }, [historicalData]);

  const generatePredictions = () => {
    if (!historicalData) return;

    setLoading(true);
    
    setTimeout(() => {
      const generateFuturePredictions = (historical: any[], months: number) => {
        const predictions = [];
        const lastDate = new Date(historical[historical.length - 1].date);
        
        for (let i = 1; i <= months; i++) {
          const futureDate = new Date(lastDate);
          futureDate.setMonth(futureDate.getMonth() + i);
          
          const predictedValue = predictNextValue(historical, i);
          
          // Add confidence interval
          const uncertainty = i * 0.5; // Uncertainty grows with time
          const upper = predictedValue + uncertainty;
          const lower = predictedValue - uncertainty;
          
          predictions.push({
            date: futureDate,
            value: predictedValue,
            upper: parseFloat(upper.toFixed(2)),
            lower: parseFloat(lower.toFixed(2))
          });
        }
        
        return predictions;
      };

      const predictionData = {
        exchangeRates: {
          expected: calculateExpected(historicalData.exchangeRates),
          predictions: generateFuturePredictions(historicalData.exchangeRates, predictionMonths)
        },
        discountRates: {
          expected: calculateExpected(historicalData.discountRates),
          predictions: generateFuturePredictions(historicalData.discountRates, predictionMonths)
        },
        inflationRates: {
          expected: calculateExpected(historicalData.inflationRates),
          predictions: generateFuturePredictions(historicalData.inflationRates, predictionMonths)
        },
        egyptianPoundIndex: {
          expected: calculateExpected(historicalData.egyptianPoundIndex),
          predictions: generateFuturePredictions(historicalData.egyptianPoundIndex, predictionMonths)
        }
      };

      setPredictions(predictionData);
      onPredictionsGenerated(predictionData);
      setLoading(false);
    }, 1500);
  };

  if (!historicalData) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-12 text-center">
        <Brain className="w-16 h-16 mx-auto mb-4 text-slate-300" />
        <h3 className="text-xl mb-2 text-slate-600">No Historical Data</h3>
        <p className="text-slate-500">Please load historical data first to generate predictions.</p>
      </div>
    );
  }

  const formatPredictionChart = (historical: any[], predicted: any[]) => {
    const historicalFormatted = historical.slice(-24).map(point => ({
      date: formatDate(new Date(point.date)),
      historical: point.value,
      timestamp: new Date(point.date).getTime()
    }));

    const predictedFormatted = predicted.map(point => ({
      date: formatDate(new Date(point.date)),
      predicted: point.value,
      upper: point.upper,
      lower: point.lower,
      timestamp: new Date(point.date).getTime()
    }));

    return [...historicalFormatted, ...predictedFormatted].sort((a, b) => a.timestamp - b.timestamp);
  };

  return (
    <div className="space-y-6">
      {/* Prediction Controls */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Brain className="w-8 h-8 text-purple-600" />
            <div>
              <h2 className="text-2xl">Prediction Engine</h2>
              <p className="text-slate-600">Machine Learning-based Financial Forecasting</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-slate-500" />
              <label className="text-sm text-slate-600">Forecast Period:</label>
              <select 
                value={predictionMonths}
                onChange={(e) => setPredictionMonths(parseInt(e.target.value))}
                className="px-3 py-2 border border-slate-300 rounded-md"
              >
                <option value={6}>6 Months</option>
                <option value={12}>12 Months</option>
                <option value={24}>24 Months</option>
                <option value={36}>36 Months</option>
              </select>
            </div>
            
            <button
              onClick={generatePredictions}
              disabled={loading}
              className="px-6 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Generating...' : 'Regenerate'}
            </button>
          </div>
        </div>

        {/* Prediction Method Info */}
        <div className="grid md:grid-cols-3 gap-4">
          <div className="border border-slate-200 rounded-lg p-4">
            <h4 className="mb-2 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-600" />
              Weighted Moving Average
            </h4>
            <p className="text-sm text-slate-600">Recent data points are given higher weights for trend analysis</p>
          </div>
          <div className="border border-slate-200 rounded-lg p-4">
            <h4 className="mb-2 flex items-center gap-2">
              <Activity className="w-5 h-5 text-green-600" />
              Linear Regression
            </h4>
            <p className="text-sm text-slate-600">Statistical method to identify underlying trends and patterns</p>
          </div>
          <div className="border border-slate-200 rounded-lg p-4">
            <h4 className="mb-2 flex items-center gap-2">
              <Brain className="w-5 h-5 text-purple-600" />
              Confidence Intervals
            </h4>
            <p className="text-sm text-slate-600">Upper and lower bounds increase with prediction timeframe</p>
          </div>
        </div>
      </div>

      {predictions && (
        <>
          {/* Expected Values */}
          <div className="grid md:grid-cols-4 gap-4">
            <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg shadow-lg p-6 text-white">
              <h3 className="text-sm opacity-90 mb-2">Expected Exchange Rate</h3>
              <p className="text-3xl">{predictions.exchangeRates.expected}</p>
              <p className="text-sm opacity-75 mt-1">EGP/USD</p>
            </div>
            
            <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg shadow-lg p-6 text-white">
              <h3 className="text-sm opacity-90 mb-2">Expected Discount Rate</h3>
              <p className="text-3xl">{predictions.discountRates.expected}%</p>
              <p className="text-sm opacity-75 mt-1">Central Bank Rate</p>
            </div>
            
            <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg shadow-lg p-6 text-white">
              <h3 className="text-sm opacity-90 mb-2">Expected Inflation</h3>
              <p className="text-3xl">{predictions.inflationRates.expected}%</p>
              <p className="text-sm opacity-75 mt-1">Annual Rate</p>
            </div>
            
            <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-lg shadow-lg p-6 text-white">
              <h3 className="text-sm opacity-90 mb-2">Expected EGP Index</h3>
              <p className="text-3xl">{predictions.egyptianPoundIndex.expected}</p>
              <p className="text-sm opacity-75 mt-1">Index Value</p>
            </div>
          </div>

          {/* Prediction Charts */}
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Exchange Rate Prediction */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl mb-4">Exchange Rate Forecast (EGP/USD)</h3>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={formatPredictionChart(historicalData.exchangeRates, predictions.exchangeRates.predictions)}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" tick={{ fontSize: 12 }} interval="preserveStartEnd" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area type="monotone" dataKey="upper" stackId="1" stroke="none" fill="#93c5fd" fillOpacity={0.3} name="Upper Bound" />
                  <Area type="monotone" dataKey="lower" stackId="2" stroke="none" fill="#93c5fd" fillOpacity={0.3} name="Lower Bound" />
                  <Line type="monotone" dataKey="historical" stroke="#3b82f6" strokeWidth={2} name="Historical" />
                  <Line type="monotone" dataKey="predicted" stroke="#f97316" strokeWidth={2} strokeDasharray="5 5" name="Predicted" />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Discount Rate Prediction */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl mb-4">Discount Rate Forecast</h3>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={formatPredictionChart(historicalData.discountRates, predictions.discountRates.predictions)}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" tick={{ fontSize: 12 }} interval="preserveStartEnd" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area type="monotone" dataKey="upper" stackId="1" stroke="none" fill="#c4b5fd" fillOpacity={0.3} name="Upper Bound" />
                  <Area type="monotone" dataKey="lower" stackId="2" stroke="none" fill="#c4b5fd" fillOpacity={0.3} name="Lower Bound" />
                  <Line type="monotone" dataKey="historical" stroke="#a855f7" strokeWidth={2} name="Historical" />
                  <Line type="monotone" dataKey="predicted" stroke="#f97316" strokeWidth={2} strokeDasharray="5 5" name="Predicted" />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Inflation Rate Prediction */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl mb-4">Inflation Rate Forecast</h3>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={formatPredictionChart(historicalData.inflationRates, predictions.inflationRates.predictions)}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" tick={{ fontSize: 12 }} interval="preserveStartEnd" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area type="monotone" dataKey="upper" stackId="1" stroke="none" fill="#fed7aa" fillOpacity={0.3} name="Upper Bound" />
                  <Area type="monotone" dataKey="lower" stackId="2" stroke="none" fill="#fed7aa" fillOpacity={0.3} name="Lower Bound" />
                  <Line type="monotone" dataKey="historical" stroke="#f97316" strokeWidth={2} name="Historical" />
                  <Line type="monotone" dataKey="predicted" stroke="#dc2626" strokeWidth={2} strokeDasharray="5 5" name="Predicted" />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* EGP Index Prediction */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-xl mb-4">Egyptian Pound Index Forecast</h3>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={formatPredictionChart(historicalData.egyptianPoundIndex, predictions.egyptianPoundIndex.predictions)}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" tick={{ fontSize: 12 }} interval="preserveStartEnd" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area type="monotone" dataKey="upper" stackId="1" stroke="none" fill="#86efac" fillOpacity={0.3} name="Upper Bound" />
                  <Area type="monotone" dataKey="lower" stackId="2" stroke="none" fill="#86efac" fillOpacity={0.3} name="Lower Bound" />
                  <Line type="monotone" dataKey="historical" stroke="#22c55e" strokeWidth={2} name="Historical" />
                  <Line type="monotone" dataKey="predicted" stroke="#f97316" strokeWidth={2} strokeDasharray="5 5" name="Predicted" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Prediction Table */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h3 className="text-xl mb-4">Detailed Forecast Table (Next 12 Months)</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-100">
                  <tr>
                    <th className="p-3 text-left">Date</th>
                    <th className="p-3 text-right">Exchange Rate</th>
                    <th className="p-3 text-right">Discount Rate</th>
                    <th className="p-3 text-right">Inflation Rate</th>
                    <th className="p-3 text-right">EGP Index</th>
                  </tr>
                </thead>
                <tbody>
                  {predictions.exchangeRates.predictions.slice(0, 12).map((_, index) => (
                    <tr key={index} className="border-b border-slate-200 hover:bg-slate-50">
                      <td className="p-3">{formatDate(predictions.exchangeRates.predictions[index].date)}</td>
                      <td className="p-3 text-right">{predictions.exchangeRates.predictions[index].value}</td>
                      <td className="p-3 text-right">{predictions.discountRates.predictions[index].value}%</td>
                      <td className="p-3 text-right">{predictions.inflationRates.predictions[index].value}%</td>
                      <td className="p-3 text-right">{predictions.egyptianPoundIndex.predictions[index].value}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
