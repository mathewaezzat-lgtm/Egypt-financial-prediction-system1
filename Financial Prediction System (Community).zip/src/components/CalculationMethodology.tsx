import { BookOpen, TrendingUp, Calculator, DollarSign } from 'lucide-react';

export function CalculationMethodology() {
  return (
    <div className="bg-white rounded-lg shadow-lg p-8 space-y-8">
      <div>
        <h1 className="text-3xl mb-2 flex items-center gap-3">
          <BookOpen className="w-8 h-8 text-blue-600" />
          Calculation Methodology Guide
        </h1>
        <p className="text-slate-600">Complete mathematical formulas and methods used for predictions and arbitrage detection</p>
      </div>

      {/* PREDICTION CALCULATIONS */}
      <section className="border-t pt-6">
        <h2 className="text-2xl mb-4 flex items-center gap-2">
          <TrendingUp className="w-6 h-6 text-purple-600" />
          1. Prediction Calculations
        </h2>

        {/* Expected Value Calculation */}
        <div className="bg-purple-50 border border-purple-200 rounded-lg p-6 mb-6">
          <h3 className="text-xl mb-3">1.1 Expected Value (Weighted Moving Average)</h3>
          <p className="text-slate-700 mb-4">
            The expected value uses recent historical data with higher weights for more recent observations.
          </p>
          
          <div className="bg-white rounded p-4 mb-4">
            <p className="text-sm text-slate-600 mb-2">Formula:</p>
            <div className="font-mono text-sm bg-slate-100 p-3 rounded overflow-x-auto">
              Expected = Σ(Value<sub>i</sub> × Weight<sub>i</sub>) / Σ(Weight<sub>i</sub>)
            </div>
            <p className="text-sm text-slate-600 mt-2">Where: Weight<sub>i</sub> = i (linear weighting, i = 1 to 12)</p>
          </div>

          <div className="bg-blue-50 border-l-4 border-blue-500 p-4">
            <p className="text-sm mb-2"><strong>Example Calculation:</strong></p>
            <p className="text-sm text-slate-700">Using last 12 months of data (most recent has weight 12, oldest has weight 1):</p>
            <ul className="text-sm text-slate-700 mt-2 space-y-1">
              <li>• Month 1 (oldest): Value = 45.0, Weight = 1 → 45.0 × 1 = 45.0</li>
              <li>• Month 2: Value = 46.0, Weight = 2 → 46.0 × 2 = 92.0</li>
              <li>• ...</li>
              <li>• Month 12 (newest): Value = 47.61, Weight = 12 → 47.61 × 12 = 571.32</li>
              <li className="mt-2"><strong>Expected = Sum of weighted values / Sum of weights</strong></li>
              <li><strong>Expected = (45.0 + 92.0 + ... + 571.32) / (1 + 2 + ... + 12)</strong></li>
            </ul>
          </div>
        </div>

        {/* Trend Calculation */}
        <div className="bg-purple-50 border border-purple-200 rounded-lg p-6 mb-6">
          <h3 className="text-xl mb-3">1.2 Trend Calculation (Linear Regression)</h3>
          <p className="text-slate-700 mb-4">
            Identifies the underlying trend using simple linear regression on the last 12 months of data.
          </p>
          
          <div className="bg-white rounded p-4 mb-4">
            <p className="text-sm text-slate-600 mb-2">Linear Regression Formula:</p>
            <div className="font-mono text-sm bg-slate-100 p-3 rounded overflow-x-auto space-y-2">
              <div>Slope (m) = [n × Σ(x<sub>i</sub>y<sub>i</sub>) - Σ(x<sub>i</sub>) × Σ(y<sub>i</sub>)] / [n × Σ(x<sub>i</sub>²) - (Σx<sub>i</sub>)²]</div>
            </div>
            <p className="text-sm text-slate-600 mt-2">Where:</p>
            <ul className="text-sm text-slate-600 mt-1 space-y-1">
              <li>• n = number of data points (12 months)</li>
              <li>• x<sub>i</sub> = time index (0, 1, 2, ..., 11)</li>
              <li>• y<sub>i</sub> = value at time x<sub>i</sub></li>
            </ul>
          </div>

          <div className="bg-blue-50 border-l-4 border-blue-500 p-4">
            <p className="text-sm mb-2"><strong>Example Calculation:</strong></p>
            <p className="text-sm text-slate-700">For exchange rate trend over 12 months:</p>
            <ul className="text-sm text-slate-700 mt-2 space-y-1">
              <li>• Σx = 0 + 1 + 2 + ... + 11 = 66</li>
              <li>• Σy = 47.55 + 47.60 + 47.58 + ... = 571.44 (example sum)</li>
              <li>• Σ(xy) = (0×47.55) + (1×47.60) + (2×47.58) + ... = 3,150.2</li>
              <li>• Σ(x²) = 0² + 1² + 2² + ... + 11² = 506</li>
              <li>• n = 12</li>
              <li className="mt-2"><strong>Slope = [12 × 3150.2 - 66 × 571.44] / [12 × 506 - 66²]</strong></li>
              <li><strong>Slope = [37,802.4 - 37,715.04] / [6,072 - 4,356] = 87.36 / 1,716 = 0.0509</strong></li>
              <li className="mt-2 text-blue-700">Interpretation: Exchange rate increasing by ~0.05 EGP/USD per month</li>
            </ul>
          </div>
        </div>

        {/* Future Prediction */}
        <div className="bg-purple-50 border border-purple-200 rounded-lg p-6 mb-6">
          <h3 className="text-xl mb-3">1.3 Future Value Prediction</h3>
          <p className="text-slate-700 mb-4">
            Combines expected value with trend to predict future values.
          </p>
          
          <div className="bg-white rounded p-4 mb-4">
            <p className="text-sm text-slate-600 mb-2">Prediction Formula:</p>
            <div className="font-mono text-sm bg-slate-100 p-3 rounded overflow-x-auto">
              Predicted Value = Expected + (Trend × Months Ahead)
            </div>
          </div>

          <div className="bg-blue-50 border-l-4 border-blue-500 p-4">
            <p className="text-sm mb-2"><strong>Example Prediction:</strong></p>
            <ul className="text-sm text-slate-700 space-y-1">
              <li>• Expected Value (weighted avg) = 47.60 EGP/USD</li>
              <li>• Trend (slope) = 0.0509 EGP/USD per month</li>
              <li>• Months Ahead = 6 months</li>
              <li className="mt-2"><strong>Predicted (6 months) = 47.60 + (0.0509 × 6)</strong></li>
              <li><strong>Predicted (6 months) = 47.60 + 0.3054 = 47.91 EGP/USD</strong></li>
            </ul>
          </div>
        </div>

        {/* Confidence Intervals */}
        <div className="bg-purple-50 border border-purple-200 rounded-lg p-6">
          <h3 className="text-xl mb-3">1.4 Confidence Intervals</h3>
          <p className="text-slate-700 mb-4">
            Uncertainty bounds that increase with prediction timeframe.
          </p>
          
          <div className="bg-white rounded p-4 mb-4">
            <p className="text-sm text-slate-600 mb-2">Confidence Interval Formula:</p>
            <div className="font-mono text-sm bg-slate-100 p-3 rounded overflow-x-auto space-y-2">
              <div>Uncertainty = Months Ahead × 0.5</div>
              <div>Upper Bound = Predicted Value + Uncertainty</div>
              <div>Lower Bound = Predicted Value - Uncertainty</div>
            </div>
          </div>

          <div className="bg-blue-50 border-l-4 border-blue-500 p-4">
            <p className="text-sm mb-2"><strong>Example:</strong></p>
            <ul className="text-sm text-slate-700 space-y-1">
              <li>• Predicted (6 months) = 47.91 EGP/USD</li>
              <li>• Uncertainty = 6 × 0.5 = 3.0</li>
              <li>• Upper Bound = 47.91 + 3.0 = 50.91 EGP/USD</li>
              <li>• Lower Bound = 47.91 - 3.0 = 44.91 EGP/USD</li>
            </ul>
          </div>
        </div>
      </section>

      {/* ARBITRAGE CALCULATIONS */}
      <section className="border-t pt-6">
        <h2 className="text-2xl mb-4 flex items-center gap-2">
          <Calculator className="w-6 h-6 text-green-600" />
          2. Arbitrage Opportunity Calculations
        </h2>

        {/* Currency Arbitrage */}
        <div className="bg-green-50 border border-green-200 rounded-lg p-6 mb-6">
          <h3 className="text-xl mb-3">2.1 Currency Arbitrage</h3>
          <p className="text-slate-700 mb-4">
            Exploits differences between current and predicted exchange rates.
          </p>
          
          <div className="bg-white rounded p-4 mb-4">
            <p className="text-sm text-slate-600 mb-2">Formula:</p>
            <div className="font-mono text-sm bg-slate-100 p-3 rounded overflow-x-auto space-y-2">
              <div>Exchange Rate Difference (%) = [(Predicted Rate - Current Rate) / Current Rate] × 100</div>
              <div>Profit = Investment Amount × |Exchange Rate Difference| / 100</div>
              <div>Profit Percentage = |Exchange Rate Difference|</div>
            </div>
          </div>

          <div className="bg-blue-50 border-l-4 border-blue-500 p-4">
            <p className="text-sm mb-2"><strong>Example:</strong></p>
            <ul className="text-sm text-slate-700 space-y-1">
              <li>• Current Rate = 47.61 EGP/USD</li>
              <li>• Predicted Rate (6 months) = 47.91 EGP/USD</li>
              <li>• Investment = $10,000</li>
              <li className="mt-2"><strong>Rate Diff (%) = [(47.91 - 47.61) / 47.61] × 100 = 0.63%</strong></li>
              <li><strong>Profit = $10,000 × 0.63 / 100 = $63</strong></li>
              <li className="mt-2 text-green-700">Strategy: EGP expected to depreciate by 0.63%</li>
            </ul>
          </div>
        </div>

        {/* Interest Rate Arbitrage */}
        <div className="bg-green-50 border border-green-200 rounded-lg p-6 mb-6">
          <h3 className="text-xl mb-3">2.2 Interest Rate Arbitrage</h3>
          <p className="text-slate-700 mb-4">
            Capitalizes on expected changes in central bank discount rates.
          </p>
          
          <div className="bg-white rounded p-4 mb-4">
            <p className="text-sm text-slate-600 mb-2">Formula:</p>
            <div className="font-mono text-sm bg-slate-100 p-3 rounded overflow-x-auto space-y-2">
              <div>Discount Rate Difference = Predicted Rate - Current Rate</div>
              <div>Profit (6 months) = (Investment × Current Rate × 0.5) / 100</div>
              <div>Profit Percentage = Current Rate / 2</div>
            </div>
          </div>

          <div className="bg-blue-50 border-l-4 border-blue-500 p-4">
            <p className="text-sm mb-2"><strong>Example:</strong></p>
            <ul className="text-sm text-slate-700 space-y-1">
              <li>• Current Discount Rate = 27.25%</li>
              <li>• Predicted Rate (6 months) = 24.75%</li>
              <li>• Investment = $10,000</li>
              <li className="mt-2"><strong>Rate Difference = 24.75 - 27.25 = -2.5%</strong></li>
              <li><strong>Profit (6 mo) = ($10,000 × 27.25 × 0.5) / 100 = $1,362.50</strong></li>
              <li><strong>Profit Percentage = 27.25 / 2 = 13.63%</strong></li>
              <li className="mt-2 text-green-700">Strategy: Lock in current high rates before decrease</li>
            </ul>
          </div>
        </div>

        {/* Inflation Hedge */}
        <div className="bg-green-50 border border-green-200 rounded-lg p-6 mb-6">
          <h3 className="text-xl mb-3">2.3 Inflation Hedge Arbitrage</h3>
          <p className="text-slate-700 mb-4">
            Protects against inflation by calculating real returns.
          </p>
          
          <div className="bg-white rounded p-4 mb-4">
            <p className="text-sm text-slate-600 mb-2">Formula:</p>
            <div className="font-mono text-sm bg-slate-100 p-3 rounded overflow-x-auto space-y-2">
              <div>Inflation Difference = Predicted Inflation - Current Inflation</div>
              <div>Real Return = Current Discount Rate - Predicted Inflation</div>
              <div>Profit = (Investment × max(Real Return, 0)) / 100</div>
            </div>
          </div>

          <div className="bg-blue-50 border-l-4 border-blue-500 p-4">
            <p className="text-sm mb-2"><strong>Example:</strong></p>
            <ul className="text-sm text-slate-700 space-y-1">
              <li>• Current Inflation = 12.5%</li>
              <li>• Predicted Inflation (6 months) = 15.0%</li>
              <li>• Current Discount Rate = 27.25%</li>
              <li>• Investment = $10,000</li>
              <li className="mt-2"><strong>Inflation Diff = 15.0 - 12.5 = +2.5%</strong></li>
              <li><strong>Real Return = 27.25 - 15.0 = 12.25%</strong></li>
              <li><strong>Profit = ($10,000 × 12.25) / 100 = $1,225</strong></li>
              <li className="mt-2 text-green-700">Strategy: Inflation-protected securities to preserve real value</li>
            </ul>
          </div>
        </div>

        {/* Carry Trade */}
        <div className="bg-green-50 border border-green-200 rounded-lg p-6 mb-6">
          <h3 className="text-xl mb-3">2.4 Carry Trade Opportunity</h3>
          <p className="text-slate-700 mb-4">
            Net profit after adjusting for interest rate, inflation, and currency risk.
          </p>
          
          <div className="bg-white rounded p-4 mb-4">
            <p className="text-sm text-slate-600 mb-2">Formula:</p>
            <div className="font-mono text-sm bg-slate-100 p-3 rounded overflow-x-auto space-y-2">
              <div>Currency Risk (%) = Exchange Rate Difference / 2</div>
              <div>Carry Potential = Discount Rate - (Inflation + Currency Risk)</div>
              <div>Profit = (Investment × Carry Potential) / 100</div>
            </div>
          </div>

          <div className="bg-blue-50 border-l-4 border-blue-500 p-4">
            <p className="text-sm mb-2"><strong>Example:</strong></p>
            <ul className="text-sm text-slate-700 space-y-1">
              <li>• Discount Rate = 27.25%</li>
              <li>• Inflation = 12.5%</li>
              <li>• Exchange Rate Diff = 0.63%</li>
              <li>• Investment = $10,000</li>
              <li className="mt-2"><strong>Currency Risk = 0.63 / 2 = 0.315%</strong></li>
              <li><strong>Carry Potential = 27.25 - (12.5 + 0.315) = 14.435%</strong></li>
              <li><strong>Profit = ($10,000 × 14.435) / 100 = $1,443.50</strong></li>
              <li className="mt-2 text-green-700">Strategy: Positive carry after all adjustments</li>
            </ul>
          </div>
        </div>

        {/* Synthetic Arbitrage */}
        <div className="bg-green-50 border border-green-200 rounded-lg p-6">
          <h3 className="text-xl mb-3">2.5 Synthetic Arbitrage</h3>
          <p className="text-slate-700 mb-4">
            Detects market inefficiencies by comparing synthetic vs. actual predicted rates.
          </p>
          
          <div className="bg-white rounded p-4 mb-4">
            <p className="text-sm text-slate-600 mb-2">Formula:</p>
            <div className="font-mono text-sm bg-slate-100 p-3 rounded overflow-x-auto space-y-2">
              <div>Synthetic Rate = Current Rate × (1 + Inflation / 100)</div>
              <div>Arbitrage Gap (%) = [(Actual Predicted - Synthetic Rate) / Synthetic Rate] × 100</div>
              <div>Profit = (Investment × |Arbitrage Gap|) / 100</div>
            </div>
          </div>

          <div className="bg-blue-50 border-l-4 border-blue-500 p-4">
            <p className="text-sm mb-2"><strong>Example:</strong></p>
            <ul className="text-sm text-slate-700 space-y-1">
              <li>• Current Exchange Rate = 47.61 EGP/USD</li>
              <li>• Current Inflation = 12.5%</li>
              <li>• Actual Predicted Rate = 47.91 EGP/USD</li>
              <li>• Investment = $10,000</li>
              <li className="mt-2"><strong>Synthetic Rate = 47.61 × (1 + 12.5/100) = 47.61 × 1.125 = 53.56</strong></li>
              <li><strong>Arbitrage Gap = [(47.91 - 53.56) / 53.56] × 100 = -10.55%</strong></li>
              <li><strong>Profit = ($10,000 × 10.55) / 100 = $1,055</strong></li>
              <li className="mt-2 text-green-700">Market inefficiency: Predicted rate lower than inflation-adjusted synthetic rate</li>
            </ul>
          </div>
        </div>
      </section>

      {/* RISK ASSESSMENT */}
      <section className="border-t pt-6">
        <h2 className="text-2xl mb-4 flex items-center gap-2">
          <DollarSign className="w-6 h-6 text-orange-600" />
          3. Risk Assessment Criteria
        </h2>

        <div className="bg-orange-50 border border-orange-200 rounded-lg p-6">
          <div className="grid md:grid-cols-3 gap-4">
            <div className="bg-white rounded p-4">
              <div className="w-8 h-8 rounded bg-green-100 flex items-center justify-center mb-2">
                <span className="text-green-700 font-bold">L</span>
              </div>
              <h4 className="mb-2">Low Risk</h4>
              <ul className="text-sm text-slate-600 space-y-1">
                <li>• Interest rate arbitrage</li>
                <li>• Government securities</li>
                <li>• Stable, predictable markets</li>
                <li>• Low volatility</li>
              </ul>
            </div>

            <div className="bg-white rounded p-4">
              <div className="w-8 h-8 rounded bg-orange-100 flex items-center justify-center mb-2">
                <span className="text-orange-700 font-bold">M</span>
              </div>
              <h4 className="mb-2">Medium Risk</h4>
              <ul className="text-sm text-slate-600 space-y-1">
                <li>• Currency arbitrage &lt; 5%</li>
                <li>• Inflation hedges</li>
                <li>• Synthetic arbitrage</li>
                <li>• Moderate volatility</li>
              </ul>
            </div>

            <div className="bg-white rounded p-4">
              <div className="w-8 h-8 rounded bg-red-100 flex items-center justify-center mb-2">
                <span className="text-red-700 font-bold">H</span>
              </div>
              <h4 className="mb-2">High Risk</h4>
              <ul className="text-sm text-slate-600 space-y-1">
                <li>• Currency arbitrage &gt; 5%</li>
                <li>• Carry trades (leveraged)</li>
                <li>• High volatility markets</li>
                <li>• Emerging market exposure</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* IMPORTANT NOTES */}
      <section className="border-t pt-6">
        <div className="bg-amber-50 border-l-4 border-amber-500 p-6">
          <h3 className="text-lg mb-3">⚠️ Important Considerations</h3>
          <ul className="space-y-2 text-sm text-slate-700">
            <li>• <strong>Transaction Costs:</strong> Real-world arbitrage must account for spreads, commissions, and fees</li>
            <li>• <strong>Market Liquidity:</strong> Large positions may not be executable at predicted prices</li>
            <li>• <strong>Regulatory Risks:</strong> Capital controls and regulations may limit arbitrage execution</li>
            <li>• <strong>Model Limitations:</strong> Predictions based on historical patterns may not capture future events</li>
            <li>• <strong>Time Decay:</strong> Arbitrage opportunities may disappear as markets adjust</li>
            <li>• <strong>Political Risk:</strong> Emerging markets carry additional sovereign and political risks</li>
            <li>• <strong>Leverage Risk:</strong> Carry trades using leverage can amplify losses</li>
            <li>• <strong>Data Quality:</strong> Accuracy depends on reliable, up-to-date market data</li>
          </ul>
        </div>
      </section>
    </div>
  );
}
