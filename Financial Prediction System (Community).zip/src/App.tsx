import { useState } from 'react';
import { DataUpload } from './components/DataUpload';
import { Dashboard } from './components/Dashboard';
import { PredictionEngine } from './components/PredictionEngine';
import { ArbitrageCalculator } from './components/ArbitrageCalculator';
import { CalculationMethodology } from './components/CalculationMethodology';
import { CurrencyConverter } from './components/CurrencyConverter';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';

export default function App() {
  const [historicalData, setHistoricalData] = useState<any>(null);
  const [predictions, setPredictions] = useState<any>(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-8">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8 text-white">
          <h1 className="text-4xl mb-2">Financial Prediction & Analysis System</h1>
          <p className="text-blue-200">Egyptian Market Analytics - Exchange Rates, Discount Rates, Inflation & Arbitrage Detection</p>
        </header>

        <Tabs defaultValue="upload" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 bg-slate-800">
            <TabsTrigger value="upload">Data Upload</TabsTrigger>
            <TabsTrigger value="dashboard">Historical Charts</TabsTrigger>
            <TabsTrigger value="predictions">Predictions</TabsTrigger>
            <TabsTrigger value="arbitrage">Arbitrage</TabsTrigger>
            <TabsTrigger value="converter">Converter</TabsTrigger>
            <TabsTrigger value="methodology">How It Works</TabsTrigger>
          </TabsList>

          <TabsContent value="upload">
            <DataUpload onDataLoaded={setHistoricalData} />
          </TabsContent>

          <TabsContent value="dashboard">
            <Dashboard data={historicalData} />
          </TabsContent>

          <TabsContent value="predictions">
            <PredictionEngine 
              historicalData={historicalData} 
              onPredictionsGenerated={setPredictions}
            />
          </TabsContent>

          <TabsContent value="arbitrage">
            <ArbitrageCalculator 
              historicalData={historicalData}
              predictions={predictions}
            />
          </TabsContent>

          <TabsContent value="converter">
            <CurrencyConverter historicalData={historicalData} />
          </TabsContent>

          <TabsContent value="methodology">
            <CalculationMethodology />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}